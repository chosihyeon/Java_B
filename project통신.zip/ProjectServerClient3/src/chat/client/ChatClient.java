package chat.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Scanner;

public class ChatClient {

   String chatName;
   Socket socket;

   DataInputStream dis;
   DataOutputStream dos;

   final String quitcommand = "quit";

   public void connect(String serverIP, int portNO, String chatName) {

      try {
         // 서버의 연결
         socket = new Socket(serverIP, portNO);

         dis = new DataInputStream(socket.getInputStream());
         dos = new DataOutputStream(socket.getOutputStream());

         // 대화명 저장하고 서버에 대화명을 알려줌
         this.chatName = chatName;
         send(chatName);// client가 서버한테 첫번째로 보내주는거 대화명 메시지가 아니라 commend 특별한 문장 to.setting
         // 설정 귀속말 파일을 전송하는거야 모든사람이 아니라 특정사람이 보내는거야 /to:____/메시지
         /// image:____
         // 첫번째는 대화명이다.
         System.out.println("[" + chatName + "] 채팅 서버 연결 성공(" + serverIP + ":" + portNO + ")");

      } catch (Exception e) {
         e.printStackTrace();
      }

   }

   public void send(String message) {
      try {
    	  dos.writeUTF("TEXT");
         dos.writeUTF(message);
         dos.flush();

      } catch (Exception e) {
         System.out.println("send문제야");
      }
   }

   private void receive() {
      //계속대기하면서 있는것
      new Thread(()->{
         try {
            while(true) {
                  String message = dis.readUTF();//서버로부터 메시지 수신
                  if (message.startsWith("/img"))
                  System.out.println(message);//수신한 메시지 출력 
                  
                  //닉네임 변경 메시지 처리 
                  if(message.startsWith("/rename")) {
                     String[] parts = message.split(":");
                     if(parts.length == 2) {
                        chatName=parts[1].trim();
                     }
                  }
                  
                  
            }
         }catch(Exception e) {
            System.out.println("연결이 종료");
            //System.exit(0);
         }finally {
          quit();   
         }
      }).start();
   }
   
   private void quit() {
      // 할당 받은것을 close
      try {
         dis.close();
         dos.close();
         socket.close();
         System.out.println("["+chatName+"]채팅 종료");

      } catch (Exception e) {
         e.printStackTrace();
      }
   }

   public void sendImage(String filePath) {
	    try {
	        byte[] fileBytes = Files.readAllBytes(Paths.get(filePath));
	        String encodedImage = Base64.getEncoder().encodeToString(fileBytes);
	        String fileName = Paths.get(filePath).getFileName().toString();
	        String imageMessage = "IMAGE:" + fileName + ":" + encodedImage;
	        send(imageMessage);
	        System.out.println("이미지를 전송했습니다: " + fileName);
	    } catch (IOException e) {
	        System.err.println("이미지 전송 실패: " + e.getMessage());
	    }
	}
   public static void main(String[] args) {

      final String serverIP = "localhost";
      final int portNO = 50011;

      ChatClient chatClient = new ChatClient();

      // TODO Auto-generated method stub

      // 클라이언트 구별할때 사용
      // 대화명 입력을 받아서 서버 연결시 전달
      System.out.println("대화명을 입력하세요:");
      Scanner sc = new Scanner(System.in);
      String chatName = sc.nextLine();

      // 서버 연결(connect)
      chatClient.connect(serverIP, portNO, chatName);
      // 채팅 서버로부터 메시지를 받아서 처리 -> thread 처리 (receive)
      chatClient.receive();

      // 사용자가 입력한 메시지를 서버로 전송 (send)
      while (true) {
         System.out.println("> ");// 입력받는 부분
         String message = sc.nextLine();
         chatClient.send(message);// 보내는 부분
         if (message.equals(chatClient.quitcommand))
            break;
      }

      // 사용자가 입력한 메시지에 quit command가 있으면 퇴장처리(quit)
      //chatClient.quit();

   }

}
