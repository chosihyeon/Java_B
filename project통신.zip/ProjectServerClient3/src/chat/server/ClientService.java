package chat.server;

//멘션 기능은 사비스에서 
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientService {
	ChatServer chatServer;
	Socket socket;

	DataInputStream dis;
	DataOutputStream dos;

	String clientIP;
	String chatName;
	String displayName;
	final String quitCommand = "quit";

	public ClientService(ChatServer chatServer, Socket socket) throws IOException {

		// 필요 자료 구조 초기화
		this.chatServer = chatServer;
		this.socket = socket;

		dis = new DataInputStream(socket.getInputStream());
		dos = new DataOutputStream(socket.getOutputStream());

		// 클라이언트 정보 수집 -> 서버한테 알려주기
		clientIP = socket.getInetAddress().getHostName();
		// protocol임
		chatName = dis.readUTF();
		displayName = chatName + "@" + clientIP;

		chatServer.addClientInfo(this);// 현재 객체의 주소를 전달

		// 입장 알림 ->ChatServer에게 요청
		chatServer.sendToAll(this, "입장 " + chatName);
		// 클라이언트가 보낸 메시지를 다른 채팅 참여자에게 전송-> chatServer에게 요청 -> thread(Daemon)
		receive();
	}

	public void receive() {

      new Thread(() -> {
         try {
            while (true) {
               String messageType=dis.readUTF();//메시지 타입 수신
               
               if(messageType.equalsIgnoreCase("TEXT")){//타입을 확인해서 그에 해당탕;ㅂ에 
               String message=dis.readUTF();
               if (message.startsWith("/rename ")) {
                   String newChatName = message.substring(8).trim();

                   synchronized (ChatServer.chatClientInfo) {// 닉네임 변경 동기화 처리
                      if (chatServer.chatClientInfo.containsKey(newChatName)) {
                         send("닉네임이 중복, 다른 이름 작성하시요");
                      } else {
                         chatServer.chatClientInfo.remove(chatName);// 기존 닉네임 제거
                         this.chatName = newChatName;
                         this.displayName = chatName + "@" + clientIP;
                         chatServer.chatClientInfo.put(newChatName, this);
                         chatServer.sendToAll(this, "닉네임이 [" + chatName + "]으로 변경되었습니다.");
                      }
                   }
                }
                // 멘션 메시지 처리 (/to 전송닉네임 메시지)
                else if (message.startsWith("/to ")) {
                   String[] parts = message.split(" ",3);
                   if (parts.length == 3) {
                      String targetName = parts[1].trim(); // 전송 대상 이름
                      String privateMessage = parts[2]; // 메시지 내용

                      // 대상 사용자 찾기

                            synchronized (chatServer.chatClientInfo) {
                                ClientService targetClient = chatServer.chatClientInfo.get(targetName);
                                if (targetClient != null) {
                                    // 대상 사용자에게 메시지 전송
                                    targetClient.send("[귓속말] " + chatName + " -> " + privateMessage);
                                    // 발신자에게도 알림
                                    send("[귓속말] " + targetName + "에게: " + privateMessage);
                                } else {
                                    // 대상 사용자를 찾지 못한 경우
                                    send("사용자를 찾을 수 없습니다: " + targetName);
                                }
                            }
                        } else {
                            send("잘못된 명령어 형식입니다. 사용법: /to 닉네임 메시지");
                        }
                }
                else if (messageType.equalsIgnoreCase("IMAGE")) {
             	   // 이미지 메시지 처리
                    String fileName = dis.readUTF();
                    String encodedImage = dis.readUTF();
                    String fullMessage = "IMAGE:" + fileName + ":" + encodedImage;

                    // 이미지 메시지를 모든 클라이언트에게 전달
                    chatServer.sendToAll(this, fullMessage);
                }
                    else {
                        // 일반 메시지 처리
                        chatServer.sendToAll(this, "[" + chatName + "]: " + message);
                    }
            	
            	/*String message = dis.readUTF();// 클라이언트로 부터 메시지 수신
               System.out.println(displayName + ">" + message);// 메시지출력
                */
               if (message.equals(quitCommand)) {// 클라이언트가 "quit" 명령어를 보낸 경우
                  break;
               } // 루프 종료
               }
              
            }
           } catch (Exception e) {
               quit();
              
           }
       }).start();

	}

	public void send(String message) {
		try {
			dos.writeUTF(message);
			dos.flush();

		} catch (Exception e) {

		}

	}

	public void quit() {
		try {
			// 클라이언트에게 퇴장 확인 메시지 전송 // 수정됨
			send("퇴장을 완료하였습니다. 채팅을 종료합니다.");

			// 다른 참여 클라이언트들에게 퇴장 정보 전달
			chatServer.sendToAll(this, "[퇴장] " + chatName);

			// 서버에 저장된 클라이언트 정보 삭제
			chatServer.removeClientInfo(this);

			// 할당 받은 자원 close()
			close();
		} catch (Exception e) {
			// 예외 처리 (필요 시 로그 추가)
			System.err.println("퇴장 처리 중 오류 발생: " + e.getMessage());
			e.printStackTrace();
		}

	}

	public void close() {
		try {
			dis.close();
			dos.close();
			socket.close();
		} catch (Exception e) {
		}
	}
	// 입장 알림 ->ChatServer에게 요청

	// 클라이언트 보낸 메시지를 다른 채팅 참여자에게 전송 -> chatServer에게 요청

}
