package chat.server;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Hashtable;
import java.util.Map;
import java.util.Scanner;

public class ChatServer {

	final String quitCommand = "quit";
	ServerSocket serverSocket;

	public static Map<String, ClientService> chatClientInfo = new Hashtable<>();
	// Hashmap보다는 hashtable을 많이 사용함

	public void start(int portNo) {
		try {
			serverSocket = new ServerSocket(portNo);
			System.out.println("[채팅서버] 시작(" + InetAddress.getLocalHost() + ":" + portNo + ")");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 클라이언트 연결 요청을 받아서 채팅 서비스 제공-> Daemon처리 (connectClient)
	public void connectClient() {
		Thread thread = new Thread(() -> {
			try {
				while (true) {
					// 클라이언트 연결 요청에 대한 통신을 할 socket생성
					Socket socket = serverSocket.accept();
					new ClientService(this, socket);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		thread.setDaemon(true);
		thread.start();

	}

	public void stop() {
		try {
			serverSocket.close();
			System.out.println("채팅서버종료");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void addClientInfo(ClientService clientService) {
		chatClientInfo.put(clientService.chatName, clientService);// keyvalue라고 생각하면 됨
		System.out.println(" [입장] " + clientService.displayName + " (채팅 참여자 수  :" + chatClientInfo.size() + ")");
	}

	public void sendToAll(ClientService sendr, String message) {
		String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		// 해당 client가 보낸 메시지를 다른 채팅 참여자에게 전송
		for (ClientService cs : chatClientInfo.values()) {
			if (cs != sendr) {// 메시지를 보낸 클라이언트를 제외한 나머지 클라이언트에게 메시지 전송
				cs.send("[" + sendr.chatName + "](" + timestamp + "): " + message);
			}
		}
	}

	public void removeClientInfo(ClientService clientService) {
		chatClientInfo.remove(clientService.chatName);
		System.out.println("[퇴장]" + clientService.displayName + "(채팅 참여자 수  :" + chatClientInfo.size() + ")");
	}

	public static void main(String[] args) {

		final int portNo = 50011;
		ChatServer chatServer = new ChatServer();

		// 채팅 서버 시작(start)
		chatServer.start(portNo);

		// client 연결 요청을 받아서 채팅 서비스 제공
		chatServer.connectClient();

		// 여러명이 접속할 수 있도록 -> while, thread로 만듦->daemon 처리 (connectClient)
		// server 연결을 받으면 안되기때문에
		// 종료 command 처리 (그만)

		while (true) {
			System.out.println("서버를 종료하려면 quit을 입력하고 enter를 치세요");
			Scanner sc = new Scanner(System.in);
			String command = sc.nextLine();
			if (command.equalsIgnoreCase(chatServer.quitCommand))
				break;
		}
		chatServer.stop();
	}

}
